static const char col_gray1[]       = "#282c34";
static const char col_gray2[]       = "#282c34";
static const char col_gray3[]       = "#bbc2cf";
static const char col_gray4[]       = "#bbc2cf";
static const char col_cyan[]        = "#51afef";

