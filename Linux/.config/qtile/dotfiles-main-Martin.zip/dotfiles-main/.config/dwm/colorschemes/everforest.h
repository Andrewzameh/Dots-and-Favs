static const char col_gray1[]       = "#2b3339";
static const char col_gray2[]       = "#2b3339";
static const char col_gray3[]       = "#d5c9ab";
static const char col_gray4[]       = "#d5c9ab";
static const char col_cyan[]        = "#a7c080";

