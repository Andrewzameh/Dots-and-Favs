static const char col_gray1[]       = "#282a36";
static const char col_gray2[]       = "#282a36";
static const char col_gray3[]       = "#f8f8f2";
static const char col_gray4[]       = "#f8f8f2";
static const char col_cyan[]        = "#bd93f9";

